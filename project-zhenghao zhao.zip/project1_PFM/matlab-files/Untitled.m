      if s_vm.turn_theta>1.3
        t0 = s_vm.angle_z - s_vm.turn_theta;
             n0 = 0;
   while  (abs( s_vm.angle_z-t0)>0.4)&&n0<100
              n0 =n0+1;
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',+3);
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',-3);
       s_vm = vrep1_link.car_pose_update(vrep,s_vm); 
   
   end  
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',+0.5);
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',-0.5);
  elseif s_vm.turn_theta<-1.3
        t1 = s_vm.angle_z - s_vm.turn_theta;
             n1 = 0;
   while  (abs( s_vm.angle_z-t1)>0.4)&&n1<100
              n1 =n1+1;
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',-3);
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',+3);
       s_vm = vrep1_link.car_pose_update(vrep,s_vm); 
   
   end  
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',-0.5);
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',+0.5);        
          
  elseif s_vm.turn_theta>0.5&&s_vm.turn_theta<=1.3
           t3 = s_vm.angle_z - s_vm.turn_theta;
             n3 = 0;
   while  (abs( s_vm.angle_z-t3)>0.2)&&n3<100
              n3 =n3+1;
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',+1);
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',-1);
       s_vm = vrep1_link.car_pose_update(vrep,s_vm); 
   
   end  
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',+3);
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',+2.5);
   
elseif s_vm.turn_theta<-0.5&&s_vm.turn_theta>=-1.3
      t4 = s_vm .angle_z - s_vm.turn_theta;
      n4 = 0;
   while  (abs( s_vm.angle_z-t4)>0.2)&&n4<100
       n4 = n4 + 1;
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',-1);
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',+1);
       s_vm =vrep1_link.car_pose_update(vrep,s_vm);  
   end  
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',+2.5);
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',+3)
    ;
   elseif s_vm.turn_theta<=0.5&& s_vm.turn_theta>=0.2
           
        s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',+4);
        s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',+3.5);
         s_vm =vrep1_link.car_pose_update(vrep,s_vm);  
   
  elseif s_vm.turn_theta<=-0.2&& s_vm.turn_theta>=-0.5
         
        s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',+3.5);
        s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',+4);
         s_vm =vrep1_link.car_pose_update(vrep,s_vm);  
   
       
 elseif s_vm.turn_theta>-0.2&&s_vm.turn_theta<0.2
       s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',+5);
        s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',+5);
         s_vm =vrep1_link.car_pose_update(vrep,s_vm);  
      end

      
 %%
  if s_vm.vt>0.79
        t0 = s_vm.angle_z - s_vm.vt;
             n0 = 0;
   while  (abs( s_vm.angle_z-t0)>0.4)&&n0<100
              n0 =n0+1;
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',+5*s_vm.vt);
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',-5*s_vm.vt);
       s_vm = vrep1_link.car_pose_update(vrep,s_vm); 
   
   end  
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',+0.5);
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',-0.5);
  elseif s_vm.vt<-0.79
        t1 = s_vm.angle_z - s_vm.vt;
             n1 = 0;
   while  (abs( s_vm.angle_z-t1)>0.4)&&n1<100
              n1 =n1+1;
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',-5*abs(s_vm.vt));
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',+5*abs(s_vm.vt));
       s_vm = vrep1_link.car_pose_update(vrep,s_vm); 
   
   end  
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',-0.5);
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',+0.5);        
          
  elseif s_vm.vt>0.5&&s_vm.vt<=0.79
        t3 = s_vm.angle_z - s_vm.turn_theta;
             n3 = 0;
   while  (abs( s_vm.angle_z-t3)>0.2)&&n3<100
              n3 =n3+1;
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',+5);
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',-5);
       s_vm = vrep1_link.car_pose_update(vrep,s_vm); 
   
   end  
  
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',2+1.5*abs(s_vm.vt));
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',2+1*abs(s_vm.vt));
   
elseif s_vm.vt<-0.5&&s_vm.vt>=-0.79
     t4 = s_vm .angle_z - s_vm.turn_theta;
      n4 = 0;
   while  (abs( s_vm.angle_z-t4)>0.2)&&n4<100
       n4 = n4 + 1;
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',-5);
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',+5);
       s_vm =vrep1_link.car_pose_update(vrep,s_vm);  
   end  
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',2+1*abs(s_vm.vt));
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',2+1.5*abs(s_vm.vt))
    ;
   elseif s_vm.vt<=0.5&& s_vm.vt>=0.2
           
        s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',2+1.8*abs(s_vm.vt));
        s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',2+0.8*abs(s_vm.vt));
         s_vm =vrep1_link.car_pose_update(vrep,s_vm);  
   
  elseif s_vm.vt<=-0.2&& s_vm.vt>=-0.5
         
        s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',2+0.8*abs(s_vm.vt));
        s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',2+1.8*abs(s_vm.vt));
         s_vm =vrep1_link.car_pose_update(vrep,s_vm);  
   
       
 elseif s_vm.vt>-0.2&&s_vm.vt<0.2
       s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',+3);
        s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',+3);
         s_vm =vrep1_link.car_pose_update(vrep,s_vm);  
end
      
      
      
      %%
           disp(theta_result)
      if theta_result>0.79
        t0 = s_vm.angle_z - theta_result;
             n0 = 0;
   while  (abs( s_vm.angle_z-t0)>0.4)&&n0<10
              n0 =n0+1;
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',+15*theta_result);
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',-15*theta_result);
       s_vm = vrep1_link.car_pose_update(vrep,s_vm); 
   
   end  
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',+0.65);
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',-0.65);
  elseif theta_result<-0.79
        t1 = s_vm.angle_z - theta_result;
             n1 = 0;
   while  (abs( s_vm.angle_z-t1)>0.4)&&n1<10
              n1 =n1+1;
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',-15*abs(theta_result));
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',+15*abs(theta_result));
       s_vm = vrep1_link.car_pose_update(vrep,s_vm); 
   
   end  
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',-0.65);
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',+0.65);        
          
  elseif theta_result>0.5&&theta_result<=0.79
        t3 = s_vm.angle_z - s_vm.turn_theta;
             n3 = 0;
   while  (abs( s_vm.angle_z-t3)>0.2)&&n3<30
              n3 =n3+1;
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',+10);
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',-10);
       s_vm = vrep1_link.car_pose_update(vrep,s_vm); 
   
   end  
  
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',2+1.5*abs(theta_result));
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',2+1*abs(theta_result));
   
elseif theta_result<-0.5&&theta_result>=-0.79
     t4 = s_vm .angle_z - s_vm.turn_theta;
      n4 = 0;
   while  (abs( s_vm.angle_z-t4)>0.2)&&n4<30
       n4 = n4 + 1;
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',-10);
          s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',+10);
       s_vm =vrep1_link.car_pose_update(vrep,s_vm);  
   end  
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',2+1*abs(theta_result));
    s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',2+1.5*abs(theta_result))
    ;
   elseif theta_result<=0.5&& theta_result>=0.2
           
        s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',2+1.8*abs(theta_result));
        s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',2+0.8*abs(theta_result));
         s_vm =vrep1_link.car_pose_update(vrep,s_vm);  
   
  elseif theta_result<=-0.2&& theta_result>=-0.5
         
        s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',2+0.8*abs(theta_result));
        s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',2+1.8*abs(theta_result));
         s_vm =vrep1_link.car_pose_update(vrep,s_vm);  
   
       
 elseif theta_result>-0.2&&theta_result<0.2
       s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'L',+2.39);
        s_vm = vrep1_link.wheel_velocity_set(vrep,s_vm,'R',+2.39);
         s_vm =vrep1_link.car_pose_update(vrep,s_vm);  
end
        
      
      
      